if(Math.floor(Math.random() * 6) + 1  === 4) {
    document.location.href = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
}