# Uglify

An app that makes your browsing experince extremly pai.... unique.

Available in the Chrome Webstore: https://chrome.google.com/webstore/detail/uglify/iffebpkheiniojlhbppfnmdjpfmfdbof
